
# This program calculates and displays travel expenses

# 16 Feb 2023 

# CTI-110 P1HW2 - Travel Expense

# Cory McGee

print("This program calculates and displays travel expenses")
print()

budget = float(input("Enter budget: "))
print()
name = input("Enter your travel destination:")
gas = float(input("How much do you think you will spend on gas?: "))
print()
hotel = float(input("Approximately, how much will you need for accomodation/hotel?: "))
print()
food = float(input("How much do you think you will spend on food?: "))
print()
print("-"*12,'Travel Bxpenses', 12*'-')
print("Location: ", name)
print("Initial Budget:" , budget)
print()
print("Fuel:" , gas)
print("Accomodation:" , hotel)
print("Food:" , food)
print()      
balance = budget - gas - food - hotel
#print("Remaining Balance:" ,balance)
print("Remaining Balance:" ,format(balance,',.0f'))      
      

      
      
