# CTI-110

   # I was supposed to put a comment here 

   #  McGee

   # This program takes a number grade, determines average and displays letter grade for average.

   # Enter grades for six modules

   
grades = []
mod_1 = float(input("Enter grade for Module 1: "))

mod_2 = float(input("Enter grade for Module 2: "))

mod_3 = float(input("Enter grade for Module 3: "))

mod_4 = float(input("Enter grade for Module 4: "))

mod_5 = float(input("Enter grade for Module 5: "))

mod_6 = float(input("Enter grade for Module 6: "))
grades = [mod_1, mod_2, mod_3, mod_4, mod_5, mod_6]
low = min(grades)
highest = max (grades)
avg = sum(grades)/len(grades)
sum = sum(grades)


print()
print('-'*12,'Results','-'*12)

print('Lowest Grade:'+ str(format(low,',.2f')).rjust(15))
print('Highest Grade:'+str(format(highest,',.2f')).rjust (15))
print('Sum of grades:'+str(format(sum,',.2f')).rjust (26))
print('Average:'+ str(format(avg,',.2f')).rjust(26))

print('-'*40)

if avg > 90:
    print ('Your grade is : A')
elif avg > 80:
    print ('Your grade is : B')
elif avg > 70:
    print ('Your grade is : C')
elif avg > 60:
    print('Your grade is : D')
else:
    print ('Your grade is F')
           
