  # CTI-110

   # P2HW2 - List

   # Cory McGee

   # 2 March 2023

   #

   #create a list
grade_list = []
grade = float(input("Enter grade for Module 1: "))
grade_list.append(grade)
grade = float(input("Enter grade for Module 2: "))
grade_list.append(grade)
grade = float(input("Enter grade for Module 3: "))
grade_list.append(grade)
grade = float(input("Enter grade for Module 4: "))
grade_list.append(grade)
grade = float(input("Enter grade for Module 5: "))
grade_list.append(grade)
grade = float(input("Enter grade for Module 6: "))
grade_list.append(grade)

print()
print('-'*12,'Results','-'*12)

print('Lowest Grade:'+ str(min(grade_list)).rjust(6))
print('Highest Grade:', max(grade_list))
print('Sum of grades:', sum(grade_list))
print('Average:'+ str(format(sum(grade_list)/ len(grade_list),',.2f')).rjust(12))

print('-'*40)
